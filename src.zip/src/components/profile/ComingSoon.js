import React from "react";
import "./comingsoon.scss";

const ComingSoon = () => {
  return (
    /* Coming soon div contain Image*/
    <div className="coming-soon"></div>
  );
};

export default ComingSoon;
